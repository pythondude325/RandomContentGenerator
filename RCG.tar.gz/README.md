# RandomContentGenerator

#### To deploy my Random Content Generator
enter these commands in your commandline at the desired directory

```
$ wget https://github.com/pythondude325/RandomContentGenerator/raw/master/RCG.tar.gz
$ tar -xvf RCG.tar.gz
```
